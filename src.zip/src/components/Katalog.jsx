import "./Katalog.css"

const Katalog = () => {
    return (
        <div className="Katalog">
<h1>Katalog working</h1>
        </div>
    )
}

export default Katalog